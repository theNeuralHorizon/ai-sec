/* @ds-bundle: {"format":3,"namespace":"MSCIBrandDesignSystem_e8fe2b","components":[],"sourceHashes":{"slides/deck-stage.js":"522102a1c71e","ui_kits/msci-analytics/AppShell.jsx":"859c29ed10b5","ui_kits/msci-analytics/Factsheet.jsx":"49a540a84701","ui_kits/msci-web/CTAAndFooter.jsx":"64e087b8eb5c","ui_kits/msci-web/Header.jsx":"f60550aa7ff6","ui_kits/msci-web/Hero.jsx":"53ac2a37e074","ui_kits/msci-web/Insights.jsx":"0e4935dca96b","ui_kits/msci-web/ProductGrid.jsx":"d85488228e72","ui_kits/msci-web/StatBand.jsx":"59b8c946b2f1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MSCIBrandDesignSystem_e8fe2b = window.MSCIBrandDesignSystem_e8fe2b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// slides/deck-stage.js
try { (() => {
/**
 * <deck-stage> — reusable web component for HTML decks.
 *
 * Handles:
 *  (a) speaker notes — reads <script type="application/json" id="speaker-notes">
 *      and posts {slideIndexChanged: N} to the parent window on nav.
 *  (b) keyboard navigation — ←/→, PgUp/PgDn, Space, Home/End, number keys.
 *  (c) press R to reset to slide 0 (with a tasteful keyboard hint).
 *  (d) bottom-center overlay showing slide count + hints, fades out on idle.
 *  (e) auto-scaling — inner canvas is a fixed design size (default 1920×1080)
 *      scaled with `transform: scale()` to fit the viewport, letterboxed.
 *      Set the `noscale` attribute to render at authored size (1:1) — the
 *      PPTX exporter sets this so its DOM capture sees unscaled geometry.
 *  (f) print — `@media print` lays every slide out as its own page at the
 *      design size, so the browser's Print → Save as PDF produces a clean
 *      one-page-per-slide PDF with no extra setup.
 *
 * Slides are HIDDEN, not unmounted. Non-active slides stay in the DOM with
 * `visibility: hidden` + `opacity: 0`, so their state (videos, iframes,
 * form inputs, React trees) is preserved across navigation.
 *
 * Lifecycle event — the component dispatches a `slidechange` CustomEvent on
 * itself whenever the active slide changes (including the initial mount).
 * The event bubbles and composes out of shadow DOM, so you can listen on
 * the <deck-stage> element or on document:
 *
 *   document.querySelector('deck-stage').addEventListener('slidechange', (e) => {
 *     e.detail.index         // new 0-based index
 *     e.detail.previousIndex // previous index, or -1 on init
 *     e.detail.total         // total slide count
 *     e.detail.slide         // the new active slide element
 *     e.detail.previousSlide // the prior slide element, or null on init
 *     e.detail.reason        // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
 *   });
 *
 * Persistence: current slide index is saved to localStorage keyed by the
 * document path, so refresh returns you to the same place.
 *
 * Usage:
 *   <deck-stage width="1920" height="1080">
 *     <section data-label="Title">...</section>
 *     <section data-label="Agenda">...</section>
 *   </deck-stage>
 *
 * Slides are the direct element children of <deck-stage>. Each slide is
 * automatically tagged with:
 *   - data-screen-label="NN Label"   (1-indexed, for comment flow)
 *   - data-om-validate="no_overflowing_text,no_overlapping_text,slide_sized_text"
 */

(() => {
  const DESIGN_W_DEFAULT = 1920;
  const DESIGN_H_DEFAULT = 1080;
  const STORAGE_PREFIX = 'deck-stage:slide:';
  const OVERLAY_HIDE_MS = 1800;
  const VALIDATE_ATTR = 'no_overflowing_text,no_overlapping_text,slide_sized_text';
  const pad2 = n => String(n).padStart(2, '0');
  const stylesheet = `
    :host {
      position: fixed;
      inset: 0;
      display: block;
      background: #000;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow: hidden;
    }

    .stage {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .canvas {
      position: relative;
      transform-origin: center center;
      flex-shrink: 0;
      background: #fff;
      will-change: transform;
    }

    /* Slides live in light DOM (via <slot>) so authored CSS still applies.
       We absolutely position each slotted child to stack them. */
    ::slotted(*) {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    ::slotted([data-deck-active]) {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
    }

    /* Tap zones for mobile — back/forward thirds like Stories.
       Transparent, no visible UI, don't block the overlay. */
    .tapzones {
      position: fixed;
      inset: 0;
      display: flex;
      z-index: 2147482000;
      pointer-events: none;
    }
    .tapzone {
      flex: 1;
      pointer-events: auto;
      -webkit-tap-highlight-color: transparent;
    }
    /* Only activate tap zones on coarse pointers (touch devices). */
    @media (hover: hover) and (pointer: fine) {
      .tapzones { display: none; }
    }

    .overlay {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translate(-50%, 6px) scale(0.92);
      filter: blur(6px);
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px;
      background: #000;
      color: #fff;
      border-radius: 999px;
      font-size: 12px;
      font-feature-settings: "tnum" 1;
      letter-spacing: 0.01em;
      opacity: 0;
      pointer-events: none;
      transition: opacity 260ms ease, transform 260ms cubic-bezier(.2,.8,.2,1), filter 260ms ease;
      transform-origin: center bottom;
      z-index: 2147483000;
      user-select: none;
    }
    .overlay[data-visible] {
      opacity: 1;
      pointer-events: auto;
      transform: translate(-50%, 0) scale(1);
      filter: blur(0);
    }

    .btn {
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 0;
      margin: 0;
      padding: 0;
      color: inherit;
      font: inherit;
      cursor: default;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 28px;
      min-width: 28px;
      border-radius: 999px;
      color: rgba(255,255,255,0.72);
      transition: background 140ms ease, color 140ms ease;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .btn:active { background: rgba(255,255,255,0.18); }
    .btn:focus { outline: none; }
    .btn:focus-visible { outline: none; }
    .btn::-moz-focus-inner { border: 0; }
    .btn svg { width: 14px; height: 14px; display: block; }
    .btn.reset {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.02em;
      padding: 0 10px 0 12px;
      gap: 6px;
      color: rgba(255,255,255,0.72);
    }
    .btn.reset .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      font-size: 10px;
      line-height: 1;
      color: rgba(255,255,255,0.88);
      background: rgba(255,255,255,0.12);
      border-radius: 4px;
    }

    .count {
      font-variant-numeric: tabular-nums;
      color: #fff;
      font-weight: 500;
      padding: 0 8px;
      min-width: 42px;
      text-align: center;
      font-size: 12px;
    }
    .count .sep { color: rgba(255,255,255,0.45); margin: 0 3px; font-weight: 400; }
    .count .total { color: rgba(255,255,255,0.55); }

    .divider {
      width: 1px;
      height: 14px;
      background: rgba(255,255,255,0.18);
      margin: 0 2px;
    }

    /* ── Print: one page per slide, no chrome ────────────────────────────
       The screen layout stacks every slide at inset:0 inside a scaled
       canvas; for print we want them in document flow at the authored
       design size so the browser paginates one slide per sheet. The
       @page size is set from the width/height attributes via the inline
       <style id="deck-stage-print-page"> that connectedCallback injects
       into <head> (the @page at-rule has no effect inside shadow DOM). */
    @media print {
      :host {
        position: static;
        inset: auto;
        background: none;
        overflow: visible;
        color: inherit;
      }
      .stage { position: static; display: block; }
      .canvas {
        transform: none !important;
        width: auto !important;
        height: auto !important;
        background: none;
        will-change: auto;
      }
      ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        width: var(--deck-design-w) !important;
        height: var(--deck-design-h) !important;
        box-sizing: border-box !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto;
        break-after: page;
        page-break-after: always;
        break-inside: avoid;
        overflow: hidden;
      }
      ::slotted(*:last-child) {
        break-after: auto;
        page-break-after: auto;
      }
      .overlay, .tapzones { display: none !important; }
    }
  `;
  class DeckStage extends HTMLElement {
    static get observedAttributes() {
      return ['width', 'height', 'noscale'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._index = 0;
      this._slides = [];
      this._notes = [];
      this._hideTimer = null;
      this._mouseIdleTimer = null;
      this._storageKey = STORAGE_PREFIX + (location.pathname || '/');
      this._onKey = this._onKey.bind(this);
      this._onResize = this._onResize.bind(this);
      this._onSlotChange = this._onSlotChange.bind(this);
      this._onMouseMove = this._onMouseMove.bind(this);
      this._onTapBack = this._onTapBack.bind(this);
      this._onTapForward = this._onTapForward.bind(this);
    }
    get designWidth() {
      return parseInt(this.getAttribute('width'), 10) || DESIGN_W_DEFAULT;
    }
    get designHeight() {
      return parseInt(this.getAttribute('height'), 10) || DESIGN_H_DEFAULT;
    }
    connectedCallback() {
      this._render();
      this._loadNotes();
      this._syncPrintPageRule();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      window.addEventListener('mousemove', this._onMouseMove, {
        passive: true
      });
      // Initial collection + layout happens via slotchange, which fires on mount.
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      window.removeEventListener('mousemove', this._onMouseMove);
      if (this._hideTimer) clearTimeout(this._hideTimer);
      if (this._mouseIdleTimer) clearTimeout(this._mouseIdleTimer);
    }
    attributeChangedCallback() {
      if (this._canvas) {
        this._canvas.style.width = this.designWidth + 'px';
        this._canvas.style.height = this.designHeight + 'px';
        this._canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
        this._canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
        this._fit();
        this._syncPrintPageRule();
      }
    }
    _render() {
      const style = document.createElement('style');
      style.textContent = stylesheet;
      const stage = document.createElement('div');
      stage.className = 'stage';
      const canvas = document.createElement('div');
      canvas.className = 'canvas';
      canvas.style.width = this.designWidth + 'px';
      canvas.style.height = this.designHeight + 'px';
      canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
      canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
      const slot = document.createElement('slot');
      slot.addEventListener('slotchange', this._onSlotChange);
      canvas.appendChild(slot);
      stage.appendChild(canvas);

      // Tap zones (mobile): left third = back, right third = forward.
      const tapzones = document.createElement('div');
      tapzones.className = 'tapzones export-hidden';
      tapzones.setAttribute('aria-hidden', 'true');
      const tzBack = document.createElement('div');
      tzBack.className = 'tapzone tapzone--back';
      const tzMid = document.createElement('div');
      tzMid.className = 'tapzone tapzone--mid';
      tzMid.style.pointerEvents = 'none';
      const tzFwd = document.createElement('div');
      tzFwd.className = 'tapzone tapzone--fwd';
      tzBack.addEventListener('click', this._onTapBack);
      tzFwd.addEventListener('click', this._onTapForward);
      tapzones.append(tzBack, tzMid, tzFwd);

      // Overlay: compact, solid black, with clickable controls.
      const overlay = document.createElement('div');
      overlay.className = 'overlay export-hidden';
      overlay.setAttribute('role', 'toolbar');
      overlay.setAttribute('aria-label', 'Deck controls');
      overlay.innerHTML = `
        <button class="btn prev" type="button" aria-label="Previous slide" title="Previous (←)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3L5 8l5 5"/></svg>
        </button>
        <span class="count" aria-live="polite"><span class="current">1</span><span class="sep">/</span><span class="total">1</span></span>
        <button class="btn next" type="button" aria-label="Next slide" title="Next (→)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3l5 5-5 5"/></svg>
        </button>
        <span class="divider"></span>
        <button class="btn reset" type="button" aria-label="Reset to first slide" title="Reset (R)">Reset<span class="kbd">R</span></button>
      `;
      overlay.querySelector('.prev').addEventListener('click', () => this._go(this._index - 1, 'click'));
      overlay.querySelector('.next').addEventListener('click', () => this._go(this._index + 1, 'click'));
      overlay.querySelector('.reset').addEventListener('click', () => this._go(0, 'click'));
      this._root.append(style, stage, tapzones, overlay);
      this._canvas = canvas;
      this._slot = slot;
      this._overlay = overlay;
      this._countEl = overlay.querySelector('.current');
      this._totalEl = overlay.querySelector('.total');
    }

    /** @page must live in the document stylesheet — it's a no-op inside
     *  shadow DOM. Inject/update a single <head> style tag so the print
     *  sheet matches the design size and Save-as-PDF yields one slide per
     *  page with no margins. */
    _syncPrintPageRule() {
      const id = 'deck-stage-print-page';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
        document.head.appendChild(tag);
      }
      tag.textContent = '@page { size: ' + this.designWidth + 'px ' + this.designHeight + 'px; margin: 0; } ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; overflow: visible !important; height: auto !important; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }';
    }
    _onSlotChange() {
      this._collectSlides();
      this._restoreIndex();
      this._applyIndex({
        showOverlay: false,
        broadcast: true,
        reason: 'init'
      });
      this._fit();
    }
    _collectSlides() {
      const assigned = this._slot.assignedElements({
        flatten: true
      });
      this._slides = assigned.filter(el => {
        // Skip template/style/script nodes even if someone slots them.
        const tag = el.tagName;
        return tag !== 'TEMPLATE' && tag !== 'SCRIPT' && tag !== 'STYLE';
      });
      this._slides.forEach((slide, i) => {
        const n = i + 1;
        // Determine a label for comment flow: prefer explicit data-label,
        // then an existing data-screen-label, then first heading, else "Slide".
        let label = slide.getAttribute('data-label');
        if (!label) {
          const existing = slide.getAttribute('data-screen-label');
          if (existing) {
            // Strip any leading number the author may have included.
            label = existing.replace(/^\s*\d+\s*/, '').trim() || existing;
          }
        }
        if (!label) {
          const h = slide.querySelector('h1, h2, h3, [data-title]');
          if (h) label = (h.textContent || '').trim().slice(0, 40);
        }
        if (!label) label = 'Slide';
        slide.setAttribute('data-screen-label', `${pad2(n)} ${label}`);

        // Validation attribute for comment flow / auto-checks.
        if (!slide.hasAttribute('data-om-validate')) {
          slide.setAttribute('data-om-validate', VALIDATE_ATTR);
        }
        slide.setAttribute('data-deck-slide', String(i));
      });
      if (this._totalEl) this._totalEl.textContent = String(this._slides.length || 1);
      if (this._index >= this._slides.length) this._index = Math.max(0, this._slides.length - 1);
    }
    _loadNotes() {
      const tag = document.getElementById('speaker-notes');
      if (!tag) {
        this._notes = [];
        return;
      }
      try {
        const parsed = JSON.parse(tag.textContent || '[]');
        if (Array.isArray(parsed)) this._notes = parsed;
      } catch (e) {
        console.warn('[deck-stage] Failed to parse #speaker-notes JSON:', e);
        this._notes = [];
      }
    }
    _restoreIndex() {
      try {
        const raw = localStorage.getItem(this._storageKey);
        if (raw != null) {
          const n = parseInt(raw, 10);
          if (Number.isFinite(n) && n >= 0 && n < this._slides.length) {
            this._index = n;
          }
        }
      } catch (e) {/* ignore */}
    }
    _persistIndex() {
      try {
        localStorage.setItem(this._storageKey, String(this._index));
      } catch (e) {/* ignore */}
    }
    _applyIndex({
      showOverlay = true,
      broadcast = true,
      reason = 'init'
    } = {}) {
      if (!this._slides.length) return;
      const prev = this._prevIndex == null ? -1 : this._prevIndex;
      const curr = this._index;
      this._slides.forEach((s, i) => {
        if (i === curr) s.setAttribute('data-deck-active', '');else s.removeAttribute('data-deck-active');
      });
      if (this._countEl) this._countEl.textContent = String(curr + 1);
      this._persistIndex();
      if (broadcast) {
        // (1) Legacy: host-window postMessage for speaker-notes renderers.
        try {
          window.postMessage({
            slideIndexChanged: curr
          }, '*');
        } catch (e) {}

        // (2) In-page CustomEvent on the <deck-stage> element itself.
        //     Bubbles and composes out of shadow DOM so slide code can listen:
        //       document.querySelector('deck-stage').addEventListener('slidechange', e => {
        //         e.detail.index, e.detail.previousIndex, e.detail.total, e.detail.slide, e.detail.reason
        //       });
        const detail = {
          index: curr,
          previousIndex: prev,
          total: this._slides.length,
          slide: this._slides[curr] || null,
          previousSlide: prev >= 0 ? this._slides[prev] || null : null,
          reason: reason // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
        };
        this.dispatchEvent(new CustomEvent('slidechange', {
          detail,
          bubbles: true,
          composed: true
        }));
      }
      this._prevIndex = curr;
      if (showOverlay) this._flashOverlay();
    }
    _flashOverlay() {
      if (!this._overlay) return;
      this._overlay.setAttribute('data-visible', '');
      if (this._hideTimer) clearTimeout(this._hideTimer);
      this._hideTimer = setTimeout(() => {
        this._overlay.removeAttribute('data-visible');
      }, OVERLAY_HIDE_MS);
    }
    _fit() {
      if (!this._canvas) return;
      // PPTX export sets noscale so the DOM capture sees authored-size
      // geometry — the scaled canvas is in shadow DOM, so the exporter's
      // resetTransformSelector can't reach .canvas.style.transform directly.
      if (this.hasAttribute('noscale')) {
        this._canvas.style.transform = 'none';
        return;
      }
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const s = Math.min(vw / this.designWidth, vh / this.designHeight);
      this._canvas.style.transform = `scale(${s})`;
    }
    _onResize() {
      this._fit();
    }
    _onMouseMove() {
      // Keep overlay visible while mouse moves; hide after idle.
      this._flashOverlay();
    }
    _onTapBack(e) {
      e.preventDefault();
      this._go(this._index - 1, 'tap');
    }
    _onTapForward(e) {
      e.preventDefault();
      this._go(this._index + 1, 'tap');
    }
    _onKey(e) {
      // Ignore when the user is typing.
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const key = e.key;
      let handled = true;
      if (key === 'ArrowRight' || key === 'PageDown' || key === ' ' || key === 'Spacebar') {
        this._go(this._index + 1, 'keyboard');
      } else if (key === 'ArrowLeft' || key === 'PageUp') {
        this._go(this._index - 1, 'keyboard');
      } else if (key === 'Home') {
        this._go(0, 'keyboard');
      } else if (key === 'End') {
        this._go(this._slides.length - 1, 'keyboard');
      } else if (key === 'r' || key === 'R') {
        this._go(0, 'keyboard');
      } else if (/^[0-9]$/.test(key)) {
        // 1..9 jump to that slide; 0 jumps to 10.
        const n = key === '0' ? 9 : parseInt(key, 10) - 1;
        if (n < this._slides.length) this._go(n, 'keyboard');
      } else {
        handled = false;
      }
      if (handled) {
        e.preventDefault();
        this._flashOverlay();
      }
    }
    _go(i, reason = 'api') {
      if (!this._slides.length) return;
      const clamped = Math.max(0, Math.min(this._slides.length - 1, i));
      if (clamped === this._index) {
        this._flashOverlay();
        return;
      }
      this._index = clamped;
      this._applyIndex({
        showOverlay: true,
        broadcast: true,
        reason
      });
    }

    // Public API ------------------------------------------------------------

    /** Current slide index (0-based). */
    get index() {
      return this._index;
    }
    /** Total slide count. */
    get length() {
      return this._slides.length;
    }
    /** Programmatically navigate. */
    goTo(i) {
      this._go(i, 'api');
    }
    next() {
      this._go(this._index + 1, 'api');
    }
    prev() {
      this._go(this._index - 1, 'api');
    }
    reset() {
      this._go(0, 'api');
    }
  }
  if (!customElements.get('deck-stage')) {
    customElements.define('deck-stage', DeckStage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/deck-stage.js", error: String((e && e.message) || e) }); }

// ui_kits/msci-analytics/AppShell.jsx
try { (() => {
const {
  useState
} = React;
function Sidebar({
  active,
  setActive
}) {
  const items = [['home', 'Overview'], ['bar-chart-3', 'Performance'], ['pie-chart', 'Exposures'], ['layers', 'Holdings'], ['activity', 'Risk'], ['leaf', 'ESG & Climate'], ['file-text', 'Factsheets'], ['download', 'Export']];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      background: 'var(--msci-daintree)',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 24px',
      borderBottom: '1px solid rgba(255,255,255,.08)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-logo-white.svg",
    style: {
      height: 24
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '.04em'
    }
  }, "MSCI"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 300,
      marginLeft: 6,
      color: 'rgba(255,255,255,.78)'
    }
  }, "Analytics"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: '16px 10px',
      flex: 1
    }
  }, items.map(([icon, label]) => /*#__PURE__*/React.createElement("div", {
    key: label,
    onClick: () => setActive(label),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '10px 12px',
      borderRadius: 8,
      fontSize: 13,
      fontWeight: active === label ? 600 : 400,
      color: active === label ? '#fff' : 'rgba(255,255,255,.78)',
      background: active === label ? 'rgba(255,255,255,.08)' : 'transparent',
      cursor: 'pointer',
      marginBottom: 2
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 16,
      height: 16
    }
  }), label))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      borderTop: '1px solid rgba(255,255,255,.08)',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 32,
      height: 32,
      borderRadius: '50%',
      background: 'var(--msci-primary-blue)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 600
    }
  }, "AK"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      lineHeight: 1.3
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, "Ava Kim"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'rgba(255,255,255,.55)'
    }
  }, "Portfolio manager"))));
}
function TopBar({
  index,
  setIndex
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '14px 32px',
      display: 'flex',
      alignItems: 'center',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      color: 'var(--fg-3)',
      fontSize: 13,
      fontWeight: 300
    }
  }, /*#__PURE__*/React.createElement("span", null, "Indexes"), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-right",
    style: {
      width: 14,
      height: 14
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-1)'
    }
  }, index)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--bg-2)',
      padding: '8px 14px',
      borderRadius: 999,
      width: 320,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search",
    style: {
      width: 14,
      height: 14,
      color: 'var(--fg-3)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search indexes, issuers, tickers\u2026",
    style: {
      border: 0,
      background: 'transparent',
      outline: 'none',
      flex: 1,
      fontFamily: 'inherit',
      fontSize: 13
    }
  })), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bell",
    style: {
      color: 'var(--fg-2)',
      cursor: 'pointer'
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "settings",
    style: {
      color: 'var(--fg-2)',
      cursor: 'pointer'
    }
  }));
}
window.Sidebar = Sidebar;
window.TopBar = TopBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-analytics/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-analytics/Factsheet.jsx
try { (() => {
function FactsheetHeader() {
  return /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      padding: 24,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--msci-primary-blue)',
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      marginBottom: 10
    }
  }, "Global Equity Benchmark"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 8px',
      fontSize: 32,
      fontWeight: 600,
      letterSpacing: '-0.02em'
    }
  }, "MSCI ACWI Index"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      fontWeight: 300,
      color: 'var(--fg-2)',
      maxWidth: 640,
      lineHeight: 1.5
    }
  }, "A free-float weighted equity index capturing large and mid-cap representation across 23 developed and 24 emerging market countries.")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--fg-3)',
      marginBottom: 4
    }
  }, "As of Feb. 28, 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      fontWeight: 300,
      letterSpacing: '-0.02em',
      lineHeight: 1
    }
  }, "2,845.17"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      display: 'flex',
      gap: 10,
      justifyContent: 'flex-end',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--status-success)'
    }
  }, "\u25B2 +23.74"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--status-success)'
    }
  }, "+0.84%")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20,
      display: 'flex',
      gap: 10
    }
  }, ['Overview', 'Performance', 'Characteristics', 'Top Holdings', 'Regions', 'ESG'].map((t, i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      padding: '8px 14px',
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 600,
      background: i === 0 ? 'var(--msci-primary-blue)' : 'var(--bg-2)',
      color: i === 0 ? '#fff' : 'var(--fg-2)',
      cursor: 'pointer'
    }
  }, t))));
}
function KPIRow() {
  const kpis = [{
    label: '1M return',
    value: '+2.41%',
    good: true
  }, {
    label: 'YTD return',
    value: '+6.18%',
    good: true
  }, {
    label: '3Y annualized',
    value: '+9.34%',
    good: true
  }, {
    label: '30-day vol',
    value: '12.7%',
    good: null
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 16,
      marginBottom: 20
    }
  }, kpis.map(k => /*#__PURE__*/React.createElement("div", {
    key: k.label,
    className: "panel",
    style: {
      padding: '18px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--fg-3)',
      textTransform: 'uppercase',
      letterSpacing: '.06em',
      marginBottom: 8
    }
  }, k.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      fontWeight: 600,
      letterSpacing: '-0.01em',
      color: k.good === true ? 'var(--status-success)' : k.good === false ? 'var(--status-danger)' : 'var(--fg-1)'
    }
  }, k.value))));
}
function PerformanceChart() {
  // SVG line chart, 2 series
  const W = 600,
    H = 220,
    P = 28;
  const gen = seed => {
    const pts = [];
    let v = 100;
    for (let i = 0; i < 30; i++) {
      v += Math.sin(i * 0.5 + seed) * 0.8 + Math.cos(i * 0.2 + seed * 2) * 0.6 + (i < 15 ? 0.15 : 0.25);
      pts.push(v);
    }
    return pts;
  };
  const a = gen(1.2),
    b = gen(2.8);
  const all = [...a, ...b];
  const min = Math.min(...all),
    max = Math.max(...all);
  const path = pts => pts.map((p, i) => {
    const x = P + i / (pts.length - 1) * (W - P * 2);
    const y = H - P - (p - min) / (max - min) * (H - P * 2);
    return (i === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1);
  }).join(' ');
  return /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      padding: 20,
      gridColumn: 'span 2'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, "Cumulative return (rebased)"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-3)'
    }
  }, "Jan 2026 \u2014 Feb 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, ['1M', '3M', '6M', '1Y', '5Y', 'MAX'].map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p,
    style: {
      padding: '5px 12px',
      borderRadius: 6,
      fontSize: 12,
      fontWeight: 600,
      background: i === 0 ? 'var(--bg-ice)' : 'transparent',
      color: i === 0 ? 'var(--msci-primary-blue)' : 'var(--fg-3)',
      cursor: 'pointer'
    }
  }, p)))), /*#__PURE__*/React.createElement("svg", {
    width: "100%",
    viewBox: `0 0 ${W} ${H}`,
    style: {
      display: 'block'
    }
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement("line", {
    key: i,
    x1: P,
    x2: W - P,
    y1: P + i * ((H - P * 2) / 4),
    y2: P + i * ((H - P * 2) / 4),
    stroke: "#E6E6E6",
    strokeWidth: "0.5"
  })), /*#__PURE__*/React.createElement("line", {
    x1: P,
    x2: W - P,
    y1: H - P,
    y2: H - P,
    stroke: "#707070",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: path(b),
    fill: "none",
    stroke: "#CCCCCC",
    strokeWidth: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: path(a),
    fill: "none",
    stroke: "#1A3FD6",
    strokeWidth: "2"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: '#1A3FD6'
    }
  }), " MSCI ACWI"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 12,
      color: 'var(--fg-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: '#CCC'
    }
  }), " MSCI World")));
}
function RegionDonut() {
  const data = [['United States', 62.3, '#DB7C00'], ['Japan', 5.7, '#D61A96'], ['United Kingdom', 3.6, '#529200'], ['China', 2.9, '#561AD6'], ['France', 2.6, '#16A3B6'], ['Other', 22.9, '#CCCCCC']];
  const total = 100;
  let acc = 0;
  const R = 72,
    IR = 44,
    CX = 90,
    CY = 90;
  const arc = p => {
    const a0 = acc / total * Math.PI * 2 - Math.PI / 2;
    acc += p;
    const a1 = acc / total * Math.PI * 2 - Math.PI / 2;
    const x0 = CX + R * Math.cos(a0),
      y0 = CY + R * Math.sin(a0);
    const x1 = CX + R * Math.cos(a1),
      y1 = CY + R * Math.sin(a1);
    const ix0 = CX + IR * Math.cos(a1),
      iy0 = CY + IR * Math.sin(a1);
    const ix1 = CX + IR * Math.cos(a0),
      iy1 = CY + IR * Math.sin(a0);
    const large = p > 50 ? 1 : 0;
    return `M${x0},${y0} A${R},${R} 0 ${large} 1 ${x1},${y1} L${ix0},${iy0} A${IR},${IR} 0 ${large} 0 ${ix1},${iy1} Z`;
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      marginBottom: 4
    }
  }, "Country weights"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-3)',
      marginBottom: 16
    }
  }, "Top 5 + other (%)"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "180",
    height: "180",
    viewBox: "0 0 180 180"
  }, data.map((d, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: arc(d[1]),
    fill: d[2]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      fontSize: 12
    }
  }, data.map(d => /*#__PURE__*/React.createElement("div", {
    key: d[0],
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: d[2]
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, d[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'ui-monospace',
      color: 'var(--fg-2)'
    }
  }, d[1].toFixed(1), "%"))))));
}
function HoldingsTable() {
  const rows = [['Apple Inc.', 'AAPL', 'Information Technology', 4.82, '+1.24%'], ['Microsoft Corp.', 'MSFT', 'Information Technology', 4.31, '+0.68%'], ['NVIDIA Corp.', 'NVDA', 'Information Technology', 3.87, '+2.41%'], ['Alphabet Inc. Cl A', 'GOOGL', 'Communication Services', 2.56, '−0.32%'], ['Amazon.com Inc.', 'AMZN', 'Consumer Discretionary', 2.41, '+0.92%'], ['Meta Platforms Inc.', 'META', 'Communication Services', 1.89, '+0.17%'], ['Berkshire Hathaway', 'BRK.B', 'Financials', 1.24, '−0.08%'], ['Eli Lilly & Co.', 'LLY', 'Health Care', 1.18, '+1.54%']];
  return /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      padding: 0,
      overflow: 'hidden',
      gridColumn: 'span 3'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, "Top holdings"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-3)'
    }
  }, "By portfolio weight \xB7 as of Feb. 28, 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      padding: '7px 14px',
      borderRadius: 999,
      border: '1px solid var(--border-default)',
      background: '#fff',
      color: 'var(--fg-2)',
      cursor: 'pointer'
    }
  }, "Filter"), /*#__PURE__*/React.createElement("button", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      padding: '7px 14px',
      borderRadius: 999,
      border: 0,
      background: 'var(--msci-primary-blue)',
      color: '#fff',
      cursor: 'pointer'
    }
  }, "Export .xlsx"))), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#F5F5F5'
    }
  }, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left',
      padding: '10px 20px',
      fontWeight: 600
    }
  }, "Name"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left',
      padding: '10px 20px',
      fontWeight: 600
    }
  }, "Ticker"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left',
      padding: '10px 20px',
      fontWeight: 600
    }
  }, "Sector"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right',
      padding: '10px 20px',
      fontWeight: 600
    }
  }, "Weight"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right',
      padding: '10px 20px',
      fontWeight: 600
    }
  }, "1D"))), /*#__PURE__*/React.createElement("tbody", {
    style: {
      fontWeight: 300
    }
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      background: i % 2 === 0 ? '#fff' : '#F5F5F5'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 20px'
    }
  }, r[0]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 20px',
      fontFamily: 'ui-monospace',
      fontSize: 12
    }
  }, r[1]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 20px',
      color: 'var(--fg-2)'
    }
  }, r[2]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 20px',
      textAlign: 'right',
      fontFamily: 'ui-monospace'
    }
  }, r[3].toFixed(2), "%"), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 20px',
      textAlign: 'right',
      fontFamily: 'ui-monospace',
      color: r[4].startsWith('+') ? 'var(--status-success)' : 'var(--status-danger)'
    }
  }, r[4]))))));
}
window.FactsheetHeader = FactsheetHeader;
window.KPIRow = KPIRow;
window.PerformanceChart = PerformanceChart;
window.RegionDonut = RegionDonut;
window.HoldingsTable = HoldingsTable;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-analytics/Factsheet.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/CTAAndFooter.jsx
try { (() => {
function CTASection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--bg-ice)',
      padding: '96px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container",
    style: {
      textAlign: 'center',
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 20px',
      fontSize: 44,
      fontWeight: 600,
      letterSpacing: '-0.02em',
      color: 'var(--msci-daintree)'
    }
  }, "Ready to see what clarity looks like?"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 auto 36px',
      fontSize: 17,
      fontWeight: 300,
      color: 'var(--fg-2)',
      maxWidth: 540,
      lineHeight: 1.55
    }
  }, "Talk with our team about indexes, analytics and sustainability solutions tailored to your organization."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary"
  }, "Request a demo"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost"
  }, "Contact sales"))));
}
function Footer() {
  const col = (head, links) => /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      marginBottom: 16,
      color: '#fff'
    }
  }, head), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    style: {
      fontSize: 13,
      fontWeight: 300,
      color: 'rgba(255,255,255,.72)',
      cursor: 'pointer'
    }
  }, l))));
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--msci-daintree)',
      color: '#fff',
      padding: '72px 0 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.2fr 1fr 1fr 1fr 1fr',
      gap: 40,
      paddingBottom: 48,
      borderBottom: '1px solid rgba(255,255,255,.12)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-logo-white.svg",
    style: {
      height: 32,
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 300,
      color: 'rgba(255,255,255,.72)',
      lineHeight: 1.55,
      maxWidth: 260
    }
  }, "Clarity drives action. Decision-support for the global investment community.")), col('Solutions', ['Indexes', 'Analytics', 'ESG & Climate', 'Private Assets', 'Real Capital Analytics']), col('Company', ['About', 'Leadership', 'Careers', 'Newsroom', 'Investor Relations']), col('Insights', ['Research', 'Podcasts', 'Events', 'Blog']), col('Support', ['Client login', 'Contact us', 'Accessibility', 'Media inquiries'])), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 24,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      fontSize: 12,
      color: 'rgba(255,255,255,.55)',
      fontWeight: 300
    }
  }, /*#__PURE__*/React.createElement("div", null, "\xA9 2026 MSCI Inc. All rights reserved."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer'
    }
  }, "Privacy"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer'
    }
  }, "Terms of use"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer'
    }
  }, "Cookie preferences")))));
}
window.CTASection = CTASection;
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/CTAAndFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/Header.jsx
try { (() => {
const {
  useState
} = React;
function NavItem({
  label,
  hasMenu,
  onHover,
  active
}) {
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: onHover,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      padding: '8px 4px',
      fontSize: 14,
      fontWeight: 500,
      color: active ? 'var(--msci-primary-blue)' : 'var(--fg-1)',
      cursor: 'pointer',
      borderBottom: active ? '2px solid var(--msci-primary-blue)' : '2px solid transparent'
    }
  }, label, hasMenu && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    style: {
      width: 14,
      height: 14,
      strokeWidth: 2
    }
  }));
}
function Header() {
  const [active, setActive] = useState('Solutions');
  return /*#__PURE__*/React.createElement("header", {
    style: {
      borderBottom: '1px solid var(--border-subtle)',
      background: '#fff',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--msci-daintree)',
      color: '#fff',
      fontSize: 12,
      fontWeight: 300
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container",
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 24,
      padding: '8px 48px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer',
      opacity: .85
    }
  }, "Client login"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer',
      opacity: .85
    }
  }, "Contact us"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: 'pointer',
      opacity: .85
    }
  }, "EN / \u65E5\u672C\u8A9E"))), /*#__PURE__*/React.createElement("div", {
    className: "container",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 40,
      padding: '18px 48px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-logo-color.svg",
    style: {
      height: 34
    },
    alt: "MSCI"
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      flex: 1
    }
  }, ['Solutions', 'Insights', 'About', 'Careers', 'Investor Relations'].map(l => /*#__PURE__*/React.createElement(NavItem, {
    key: l,
    label: l,
    hasMenu: l === 'Solutions' || l === 'About',
    active: active === l,
    onHover: () => setActive(l)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search",
    style: {
      cursor: 'pointer',
      color: 'var(--fg-2)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary"
  }, "Request a demo"))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/Hero.jsx
try { (() => {
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: '#fff',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.3fr 1fr',
      gap: 64,
      alignItems: 'center',
      padding: '112px 48px 120px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 20
    }
  }, "MSCI"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 72,
      fontWeight: 600,
      lineHeight: 1.02,
      letterSpacing: '-0.025em',
      color: 'var(--msci-daintree)'
    }
  }, "Clarity", /*#__PURE__*/React.createElement("br", null), "drives action."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 24,
      marginBottom: 36,
      fontSize: 19,
      fontWeight: 300,
      lineHeight: 1.55,
      color: 'var(--fg-2)',
      maxWidth: 520
    }
  }, "Decision-support tools and services for the global investment community \u2014 indexes, analytics, ESG & climate, and private assets."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary"
  }, "Explore solutions ", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right",
    style: {
      width: 16,
      height: 16
    }
  })), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost"
  }, "Read our research"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 480
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-nexus.svg",
    style: {
      position: 'absolute',
      right: -120,
      top: -40,
      width: 620,
      height: 620,
      opacity: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 60,
      bottom: 40,
      background: 'var(--bg-ice)',
      padding: '18px 22px',
      borderRadius: 12,
      boxShadow: 'var(--shadow-sm)',
      maxWidth: 280
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--msci-primary-blue)',
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      marginBottom: 6
    }
  }, "MSCI ACWI IMI"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 300,
      color: '#000'
    }
  }, "8,432.51 ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--status-success)',
      fontWeight: 600,
      marginLeft: 6
    }
  }, "+0.84%")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--fg-3)',
      marginTop: 4
    }
  }, "As of Feb. 28, 2026 \xB7 end of day")))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/Insights.jsx
try { (() => {
function InsightCard({
  tag,
  title,
  meta,
  color
}) {
  return /*#__PURE__*/React.createElement("article", {
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 220,
      borderRadius: 12,
      background: color,
      position: 'relative',
      overflow: 'hidden',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-nexus.svg",
    style: {
      position: 'absolute',
      right: -60,
      bottom: -60,
      width: 260,
      height: 260,
      opacity: 0.22,
      filter: 'brightness(0) invert(1)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--msci-primary-blue)',
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      marginBottom: 10
    }
  }, tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 12px',
      fontSize: 20,
      fontWeight: 600,
      letterSpacing: '-0.01em',
      lineHeight: 1.3
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-3)',
      fontWeight: 300
    }
  }, meta));
}
function Insights() {
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    style: {
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 12
    }
  }, "Insights"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 40,
      fontWeight: 600,
      letterSpacing: '-0.02em'
    }
  }, "Research and perspectives")), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary"
  }, "View all ", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right",
    style: {
      width: 14,
      height: 14
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement(InsightCard, {
    tag: "Climate",
    title: "How climate transition is reshaping portfolio risk in 2026",
    meta: "Research \xB7 Feb. 18, 2026 \xB7 8 min read",
    color: "#1A3FD6"
  }), /*#__PURE__*/React.createElement(InsightCard, {
    tag: "Indexes",
    title: "The evolving landscape of factor investing in emerging markets",
    meta: "Insight \xB7 Feb. 11, 2026 \xB7 6 min read",
    color: "#00A798"
  }), /*#__PURE__*/React.createElement(InsightCard, {
    tag: "Private Assets",
    title: "Private-market valuations in a higher-rates regime",
    meta: "Paper \xB7 Feb. 04, 2026 \xB7 12 min read",
    color: "#011B2B"
  }))));
}
window.Insights = Insights;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/Insights.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/ProductGrid.jsx
try { (() => {
function ProductCard({
  icon,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '32px 28px',
      borderRadius: 12,
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      transition: 'border-color 200ms, box-shadow 200ms',
      cursor: 'pointer'
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = 'var(--msci-primary-blue)';
      e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = 'var(--border-subtle)';
      e.currentTarget.style.boxShadow = 'none';
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 12,
      background: 'var(--bg-ice)',
      color: 'var(--msci-primary-blue)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 24,
      height: 24
    }
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 10px',
      fontSize: 20,
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      textTransform: 'uppercase',
      marginRight: 6
    }
  }, "MSCI"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 300
    }
  }, title)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      fontWeight: 300,
      color: 'var(--fg-2)',
      lineHeight: 1.55
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--msci-primary-blue)',
      fontSize: 13,
      fontWeight: 600
    }
  }, "Learn more ", /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right",
    style: {
      width: 14,
      height: 14
    }
  })));
}
function ProductGrid() {
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    style: {
      background: 'var(--bg-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 12
    }
  }, "Our Solutions"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 12px',
      fontSize: 40,
      fontWeight: 600,
      letterSpacing: '-0.02em',
      maxWidth: 720
    }
  }, "Comprehensive tools for every decision."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 48px',
      fontSize: 17,
      fontWeight: 300,
      color: 'var(--fg-2)',
      maxWidth: 640
    }
  }, "From indexes to climate analytics \u2014 built on consistent, transparent methodologies."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(ProductCard, {
    icon: "bar-chart-3",
    title: "Analytics"
  }, "Risk and performance tools that help investors understand, measure and manage portfolio outcomes."), /*#__PURE__*/React.createElement(ProductCard, {
    icon: "globe-2",
    title: "Indexes"
  }, "More than 250,000 indexes used by institutional investors, wealth managers and asset owners worldwide."), /*#__PURE__*/React.createElement(ProductCard, {
    icon: "leaf",
    title: "ESG & Climate"
  }, "Data, ratings and research to help integrate sustainability across investment decisions."), /*#__PURE__*/React.createElement(ProductCard, {
    icon: "building-2",
    title: "Private Assets"
  }, "Benchmarks, data and analytics spanning real estate, infrastructure and private capital."), /*#__PURE__*/React.createElement(ProductCard, {
    icon: "shield-check",
    title: "Risk Manager"
  }, "Enterprise risk analytics covering market, credit, liquidity and counterparty exposure."), /*#__PURE__*/React.createElement(ProductCard, {
    icon: "trending-up",
    title: "Factors"
  }, "Transparent, research-based factor models for systematic investment strategies."))));
}
window.ProductGrid = ProductGrid;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/ProductGrid.jsx", error: String((e && e.message) || e) }); }

// ui_kits/msci-web/StatBand.jsx
try { (() => {
function StatBand() {
  const stats = [{
    value: '$18.5T',
    label: 'Assets benchmarked to MSCI indexes'
  }, {
    value: '250,000+',
    label: 'Indexes calculated daily'
  }, {
    value: '99.7%',
    label: 'Of global equity markets covered'
  }, {
    value: '23',
    label: 'Developed market countries'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--msci-daintree)',
      color: '#fff',
      padding: '80px 0',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/msci-nexus.svg",
    style: {
      position: 'absolute',
      left: -160,
      top: -80,
      width: 520,
      height: 520,
      opacity: 0.15,
      filter: 'brightness(0) invert(1)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "container",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 40
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 56,
      fontWeight: 600,
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color: '#fff'
    }
  }, s.value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      height: 2,
      width: 32,
      background: 'var(--msci-teal)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      fontSize: 14,
      fontWeight: 300,
      color: 'rgba(255,255,255,0.82)',
      lineHeight: 1.45
    }
  }, s.label))))));
}
window.StatBand = StatBand;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/msci-web/StatBand.jsx", error: String((e && e.message) || e) }); }

})();
