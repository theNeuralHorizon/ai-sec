# MSCI Design System

A visual + interaction system for MSCI-branded artifacts — slides, mocks, prototypes, and marketing collateral. Everything here is sourced from MSCI's official Brand Visual Identity guide.

---

## About MSCI

MSCI Inc. is a leading provider of critical decision-support tools and services for the global investment community. Their products span **indexes, analytics, ESG & climate, real assets, and private assets**. The MSCI voice is authoritative, modern, and clarity-driven — captured in their tagline:

> **Clarity Drives Action**

### Product families (examples)
- MSCI **Indexes**
- MSCI **Analytics**
- MSCI **ESG & Climate**
- MSCI **Sustainability**
- MSCI **Private Assets** / **Real Capital Analytics**
- MSCI **Carbon Markets**
- MSCI **Risk Manager**
- MSCI **Wealth**

Product names follow a strict lock-up: **MSCI** set in Inter Semibold, all caps, followed by the product name in Inter Light, title case.

### Source materials used
- `assets/Brand_Visual_Identity.pdf` — MSCI's 41-page Visual Identity System (primary source of truth)
- `assets/msci-logo-color.svg` — Primary horizontal logo (Daintree + Smokey Blue nexus)
- `assets/msci-logo-white.svg` — Reverse logo for dark backgrounds

No codebase or Figma file was supplied. UI kit recreations in this system extrapolate component-level design from the brand fundamentals (color, type, radii, spacing, iconography) in the PDF — they should be treated as *exemplar interpretations of the brand*, not 1:1 recreations of shipping MSCI.com screens.

---

## File index

| Path | Purpose |
| --- | --- |
| `README.md` | This file — context, foundations, content rules |
| `SKILL.md` | Agent Skill manifest (download to use in Claude Code) |
| `colors_and_type.css` | All color + type CSS custom properties & semantic classes |
| `assets/` | Logos + source brand PDF |
| `preview/` | Design-system preview cards (rendered in Design System tab) |
| `ui_kits/msci-web/` | MSCI.com-style marketing + product-site UI kit |
| `ui_kits/msci-analytics/` | MSCI Analytics-style data product UI kit |
| `slides/` | Slide templates (title, content, quote, stat, section, comparison) |

---

## CONTENT FUNDAMENTALS

MSCI writes in **American English** and broadly follows the **AP Stylebook**. The voice is institutional, precise, and client-facing — it addresses sophisticated investors.

### Voice & tone
- **Clarity over cleverness.** "Clarity Drives Action" — copy should reduce ambiguity, not add personality for its own sake.
- **Third person / institutional.** Prefer "MSCI" or "we" at the organization level; avoid first-person singular. "You" is acceptable in instructional / in-product copy.
- **Authoritative, not promotional.** Lead with the data-point or insight; let it do the selling.
- **No exclamation points** outside of genuinely celebratory contexts (which are rare in an institutional finance brand).
- **No emoji** in brand-level copy. Iconography is the visual vocabulary.

### Casing
- **Page / deck titles:** title case — capitalize nouns, verbs, adjectives, adverbs, pronouns, and any word of 5+ letters (even conjunctions or prepositions). Always capitalize the first & last word.
  - ✓ "How Climate Transition Is Reshaping Portfolio Risk"
- **Subheads, labels, body copy, buttons, form fields:** sentence case.
  - ✓ "Run an index factsheet"
  - ✗ "Run An Index Factsheet"
- **Proper nouns** always capitalized. **Common nouns** (even important ones like "climate") never capitalized.
- **Job titles** lowercase except when they precede the holder's name.

### Punctuation
- **No Oxford comma.** "Indexes, analytics and ESG."
- **One space** after periods.
- **Ampersands** only in formal names (e.g. *JPMorgan Chase & Co.*). Otherwise "and."
- **Compound modifiers** are hyphenated before the noun: *data-driven insight*, *climate-aware portfolio*.

### Numbers, dates, currency
- Spell out **one through nine**; numerals from 10.
- **Dates:** `Feb. 15, 2026`. No comma between month-and-year only: `February 2026`. Abbreviate Jan., Feb., Aug., Sept., Oct., Nov., Dec.; spell out March–July.
- **Currencies:** ISO codes before numerals — `USD 20 billion`, `JPY 5 million`.
- **Time:** `11:00 a.m.`, `3:30 p.m.`, 12-hour clock, lowercase with periods.

### Abbreviations & acronyms
- Minimize. Spell out the full name on first reference: *Federal Open Market Committee (FOMC)*.

### Accessibility (content side)
- Short sentences, simple language, descriptive headings.
- Descriptive link text — avoid "click here."
- Always provide alt text for imagery.

### Example copy patterns

Marketing hero:
> **Clarity Drives Action**
> Decision-support tools for the global investment community.

Product section head:
> **Sustainability & Climate**
> Understand, measure and disclose climate-related financial risks.

In-product micro-copy:
> "Select a benchmark to compare exposure."
> "This factsheet will include holdings as of Feb. 28, 2026."

Chart title:
> "GEMLTESG Style Factors (1/2)"

---

## VISUAL FOUNDATIONS

MSCI's visual system is **clean, geometric, and understated** — heavy whitespace, precise type, and restrained use of a single brand color (Primary Blue) supported by a wide data-viz palette for chart-heavy contexts.

### Color
- **Signature:** Primary Blue `#1A3FD6`. The *Smokey Blue* `#0626A9` is reserved for the nexus symbol in the logo.
- **Primary text:** Daintree `#011B2B` or pure Black `#000000`.
- **Accents:** Teal `#00A798` and Turquoise `#00C4B3` for secondary emphasis.
- **Financial values:** Forest Green `#118A5E` for up / positive; Red `#E02C1C` for down / negative. These are reserved for financial ups-and-downs — do not reuse as generic status colors.
- **Neutrals:** Charcoal → Lead → Flint → Smoke → Silver → Dove → Cloud → White (grayscale ramp). Backgrounds lean heavily on White and Cloud (`#F5F5F5`).
- **Data viz:** A 30-hue ordered palette. Always use in hierarchical order, starting with `Gold` (1) and descending to `Grape` (30). Tints at 15% and 30% are available for softer fills. See `colors_and_type.css` `--viz-*` tokens.

### Typography
- **Typeface:** **Inter** — sans-serif, across all digital and print. Weights used: Light (300), Regular (400), Semibold (600). Bold exists but is sparing.
- **Headline:** Inter Semibold, title case, 32–40pt, leading tight (-10pt per brand guidance).
- **Subhead:** Inter Semibold, sentence case, 20pt, **Primary Blue**. This is the signature "MSCI subhead" treatment.
- **Body:** Inter Light, 11pt (~15–16px), black, relaxed leading.
- **Bullets:** circular, Primary Blue.
- **Secondary (fallback):** Arial, then regional equivalents for CJK / Arabic.

### Iconography
- Clean, minimalist, **line-based** icons with consistent stroke weight. Straightforward geometric construction — no rounded cartoon style, no filled/colored icons.
- See the Iconography section below for the substitution used here.

### Imagery
- **Monochromatic or minimal color palette** — bold, saturated, but sleek and editorial.
- **Never** illustration, vector art, collages, silhouettes, grayscale, or busy multi-focal-point compositions.
- **No photos of children** (MSCI policy).
- Real, unscripted moments; diverse, casual, polished-but-authentic.
- Imagery should have a background color other than white so edges are defined.

### The Nexus (graphic accent)
MSCI's mandala-like nexus symbol is reused as a graphic accent across marketing materials — sliced, cropped, and layered. It's the single most distinctive brand device. We expose it as an SVG in `assets/msci-logo-color.svg` and extract the symbol-only version in `assets/msci-nexus.svg` for reuse.

### Whitespace
Whitespace is a primary design tool at MSCI — designs lean generous. Resist filling empty space; let elements breathe.

### Rounded corners & circles
Rounded corners and circles are explicit brand motifs ("reflect warmth, clarity, connectivity"). Cards, buttons, form fields, and tables all use generous rounding (8–12px for surfaces, pill shapes for tags/chips, perfect circles for legend swatches and avatars).

### Backgrounds
- Primarily **white** or **Cloud `#F5F5F5`** surfaces.
- **Ice Blue `#F4F5FD`** for tinted sections.
- For dark / inverted sections: **Daintree `#011B2B`** (near-black navy).
- No gradients, no noise textures, no patterns. The nexus symbol is the only decorative element.

### Borders & shadows
- Borders are thin (1px) and low-contrast — `#E6E6E6` (Dove) for table rules; `#CCCCCC` (Silver) for default input borders.
- Shadows are understated — MSCI relies on whitespace, not elevation. Use `--shadow-sm` for hover lift; avoid heavy drop shadows.

### Corner radii
- 4px inputs → 8px cards → 12px large surfaces → pill for chips & CTAs.

### Motion & states
- **Hovers:** reduce opacity to ~0.7, or shift to a darker variant of the brand color (e.g. Primary Blue → Smokey Blue). No scale-up hovers.
- **Press:** subtle scale-down (0.98) OR darker color shift.
- **Transitions:** 120–200ms with a standard ease-out curve. Avoid bouncy springs — MSCI is institutional.
- **Focus:** 3px Primary-Blue outer ring at 35% opacity, no inner shadow.

### Charts
- Axis rules: 0.5pt, `#E6E6E6`. The zero X-axis line in solid `#707070`.
- Data lines: 2pt.
- Labels: Inter Regular, black. Axis labels Inter Semibold, 1pt larger.
- Legends: circular color swatches, centered under or to the right.
- Tables: alternating `#F5F5F5` / `#FFFFFF` row fills; header row Inter Semibold on `#F5F5F5`. Rounded corners on the table container.
- Pie charts are **donuts** — always with a circular subtractive area in the center, slices ordered largest-clockwise.

### Accessibility
- **WCAG AA** target (4.5:1 contrast minimum for text).
- Clear heading hierarchy (H1 → H2 → H3), keyboard-navigable, alt text, descriptive links.
- Interactive targets minimum 44×44px.

---

## ICONOGRAPHY

MSCI's visual identity specifies **clean, minimalist, line-based icons with simple geometric structures**. The PDF shows category icons for *Analytics, Index, Climate, Sustainability, Private Assets, Advanced Technology, Factors, Net-Zero, Wealth* and industry icons for *Banks, Asset Owners, Corporates, Insurance Companies*, etc. No icon font or sprite sheet was supplied.

**Substitution in use:** We use **Lucide** (MIT-licensed, CDN-available) as the primary icon set. Lucide's 1.5–2px stroke, open-path geometry, and rounded line-joins are the closest match to MSCI's style guide. Load via:

```html
<script src="https://unpkg.com/lucide@latest"></script>
<!-- then: <i data-lucide="bar-chart-3"></i> -->
```

### ⚠ Flag for the user
- **Official MSCI category/industry icons were not provided.** If MSCI has its own internal icon library (SVG sprites, icon font), please upload it and we will swap Lucide out globally.

### Rules of thumb
- **Stroke only**, never filled.
- **Stroke weight:** 1.5–2px, consistent across the set.
- **Color:** inherit current text color; brand accents (Primary Blue / Teal) for emphasis only.
- **Size:** 16 / 20 / 24 / 32 px on a 24-unit grid.
- **No emoji.** No unicode symbols as icons.
- **No custom hand-drawn SVGs** — if a needed concept isn't in Lucide, pick the nearest match and flag.

---

Questions about this guide, edge cases, or proposed additions → `msci_brand@msci.com` (per PDF).
